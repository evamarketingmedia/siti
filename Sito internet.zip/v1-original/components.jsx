/* global React, window */
const { useEffect } = React;

const Icon = ({ name, size = 16, strokeWidth = 1.6, ...rest }) => {
  const paths = {
    arrow:     <path d="M5 12h14M13 6l6 6-6 6" />,
    arrowDown: <path d="M12 5v14M6 13l6 6 6-6" />,
    check:     <polyline points="20 6 9 17 4 12" />,
    close:     <path d="M6 6l12 12M18 6L6 18" />,
    instagram: <><rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="4" /><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" /></>,
    linkedin:  <><rect x="3" y="3" width="18" height="18" rx="3" /><path d="M8 10v7M8 7v.01M12 17v-5M16 17v-3a2 2 0 0 0-4 0" /></>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
         strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" {...rest}>
      {paths[name]}
    </svg>
  );
};

/* =========================================================
   Real tool logos — simplified accurate brand marks
   ========================================================= */
const Logo = ({ kind, size = 32 }) => {
  const s = size;
  const logos = {
    whatsapp: (
      <svg width={s} height={s} viewBox="0 0 32 32" aria-label="WhatsApp">
        <rect width="32" height="32" rx="8" fill="#25D366" />
        <path d="M16 7c-4.97 0-9 3.94-9 8.8 0 1.55.42 3 1.15 4.27L7 25l5.1-1.32A9 9 0 0 0 16 24.6c4.97 0 9-3.94 9-8.8S20.97 7 16 7zm5.07 12.43c-.22.6-1.28 1.16-1.78 1.2-.45.03-.93.16-3.13-.7-2.65-1.04-4.34-3.66-4.47-3.83-.13-.17-1.07-1.4-1.07-2.66 0-1.26.67-1.88.9-2.13.23-.26.51-.32.68-.32l.49.01c.16.01.37-.06.58.44.22.51.74 1.78.8 1.9.07.13.11.27.02.45-.09.17-.13.27-.27.42-.13.15-.28.32-.4.43-.13.13-.27.27-.12.52.15.26.66 1.1 1.42 1.78.97.87 1.79 1.13 2.04 1.26.26.13.4.11.55-.07.15-.17.64-.74.81-1 .17-.26.34-.21.57-.13.23.09 1.48.7 1.74.83.26.13.43.19.49.3.06.11.06.65-.15 1.25z" fill="#fff"/>
      </svg>
    ),
    gmail: (
      <svg width={s} height={s} viewBox="0 0 32 32" aria-label="Gmail">
        <rect x="2" y="6" width="28" height="20" rx="2" fill="#fff" stroke="#E5E7EB"/>
        <path d="M2 8l14 9 14-9v2L16 19 2 10V8z" fill="#EA4335"/>
        <path d="M2 8v18h6V13L2 8z" fill="#C5221F"/>
        <path d="M30 8v18h-6V13l6-5z" fill="#FBBC04"/>
        <path d="M16 17l-6-4V8h12v5l-6 4z" fill="#fff"/>
        <path d="M2 8v.5l1.5-1.1L16 16l12.5-8.6L30 8.5V8H2z" fill="#34A853"/>
      </svg>
    ),
    sheets: (
      <svg width={s} height={s} viewBox="0 0 32 32" aria-label="Google Sheets">
        <path d="M19 3H7a2 2 0 0 0-2 2v22a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V11l-8-8z" fill="#0F9D58"/>
        <path d="M19 3v8h8l-8-8z" fill="#57BB8A"/>
        <path d="M10 14h12v2H10v-2zm0 4h12v2H10v-2zm0 4h12v2H10v-2zM10 14v10h2V14h-2zm5 0v10h2V14h-2zm5 0v10h2V14h-2z" fill="#F1F1F1"/>
      </svg>
    ),
    calendar: (
      <svg width={s} height={s} viewBox="0 0 32 32" aria-label="Google Calendar">
        <rect x="4" y="6" width="24" height="22" rx="2" fill="#fff" stroke="#E5E7EB"/>
        <path d="M4 6h24v6H4z" fill="#4285F4"/>
        <rect x="9" y="3" width="2" height="6" rx="1" fill="#1A73E8"/>
        <rect x="21" y="3" width="2" height="6" rx="1" fill="#1A73E8"/>
        <text x="16" y="24" textAnchor="middle" fontFamily="Geist, sans-serif" fontWeight="600" fontSize="11" fill="#4285F4">31</text>
      </svg>
    ),
    notion: (
      <svg width={s} height={s} viewBox="0 0 32 32" aria-label="Notion">
        <rect width="32" height="32" rx="6" fill="#fff" stroke="#E5E7EB"/>
        <path d="M10 9.5v13l2.5 1 7-12v11h2V9.5l-2.5-1-7 12V9.5h-2z" fill="#0D0D0D"/>
      </svg>
    ),
    stripe: (
      <svg width={s} height={s} viewBox="0 0 32 32" aria-label="Stripe">
        <rect width="32" height="32" rx="6" fill="#635BFF"/>
        <path d="M17.5 13c0-.8.7-1.1 1.7-1.1 1.5 0 3.4.5 4.9 1.3v-4.6c-1.6-.6-3.3-.9-4.9-.9-4 0-6.7 2.1-6.7 5.6 0 5.5 7.5 4.6 7.5 7 0 .9-.8 1.2-1.9 1.2-1.7 0-3.8-.7-5.4-1.6v4.6c1.8.8 3.7 1.1 5.4 1.1 4.1 0 7-2 7-5.6 0-5.9-7.6-4.8-7.6-7z" fill="#fff"/>
      </svg>
    ),
    chatgpt: (
      <svg width={s} height={s} viewBox="0 0 32 32" aria-label="GPT">
        <rect width="32" height="32" rx="8" fill="#0D0D0D"/>
        <path d="M22.5 14.5a4.7 4.7 0 0 0-.4-3.9 4.8 4.8 0 0 0-5.2-2.3 4.8 4.8 0 0 0-8.2 1.6 4.7 4.7 0 0 0-3.2 2.3 4.8 4.8 0 0 0 .6 5.6 4.7 4.7 0 0 0 .4 3.9 4.8 4.8 0 0 0 5.2 2.3 4.8 4.8 0 0 0 8.2-1.6 4.7 4.7 0 0 0 3.2-2.3 4.8 4.8 0 0 0-.6-5.6z" fill="#fff"/>
      </svg>
    ),
    site: (
      <svg width={s} height={s} viewBox="0 0 32 32" aria-label="Sito">
        <rect x="3" y="5" width="26" height="22" rx="2" fill="#fff" stroke="#E5E7EB"/>
        <path d="M3 5h26v5H3z" fill="#0D0D0D"/>
        <circle cx="6.5" cy="7.5" r=".8" fill="#fff"/>
        <circle cx="9" cy="7.5" r=".8" fill="#fff"/>
        <circle cx="11.5" cy="7.5" r=".8" fill="#fff"/>
        <rect x="6" y="13" width="14" height="2" rx="1" fill="#0D0D0D"/>
        <rect x="6" y="17" width="20" height="1.5" rx=".75" fill="#E5E7EB"/>
        <rect x="6" y="20" width="16" height="1.5" rx=".75" fill="#E5E7EB"/>
        <rect x="6" y="23" width="6" height="2.5" rx=".5" fill="#2563EB"/>
      </svg>
    ),
  };
  return logos[kind] || null;
};

/* Reveal-on-scroll */
function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) { e.target.classList.add("is-in"); io.unobserve(e.target); }
        });
      },
      { rootMargin: "-40px 0px -40px 0px", threshold: 0.05 }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}

const Reveal = ({ as: Tag = "div", delay = 0, className = "", style, children, ...rest }) => (
  <Tag
    className={"reveal " + className}
    style={{ transitionDelay: `${delay}ms`, ...style }}
    {...rest}
  >
    {children}
  </Tag>
);

const Brand = ({ small = false }) => (
  <a href="#top" className="brand" aria-label="Studio Quiet — home">
    <span className="mark">S</span>
    {small ? "Studio Quiet" : "Studio Quiet"}
  </a>
);

const SectionHead = ({ kicker, title, lead, center = false, children }) => (
  <Reveal className="section-head" style={center ? { alignItems: "center", textAlign: "center", margin: "0 auto", maxWidth: 760 } : { maxWidth: 760 }}>
    {kicker && <span className={"eyebrow" + (center ? " eyebrow--center" : "")}>{kicker}</span>}
    <h2 className="h-section" style={{ marginTop: 14 }} dangerouslySetInnerHTML={{ __html: title }} />
    {lead && <p className="lead" style={{ marginTop: 18 }}>{lead}</p>}
    {children}
  </Reveal>
);

Object.assign(window, { Icon, Logo, useReveal, Reveal, Brand, SectionHead });
