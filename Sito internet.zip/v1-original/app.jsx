/* global React, ReactDOM, window */
const { useState, useEffect } = React;
const {
  useReveal,
  Header, Hero,
  Problemi, ComeFunziona, CosaOffro, Risultati, Casi,
  Strumenti, Processo, FAQ, FinalCTA, Footer,
  WhatsAppFloat, ContactDialog,
  TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakToggle,
} = window;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "chiaro",
  "accent": "#2563EB",
  "showWhatsApp": true
}/*EDITMODE-END*/;

const ACCENTS = ["#2563EB", "#0D0D0D", "#0B5E3A", "#C8542B", "#7C3AED"];

function App() {
  useReveal();
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [contactOpen, setContactOpen] = useState(false);

  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute("data-theme", t.theme === "scuro" ? "dark" : "light");
    if (t.accent) {
      root.style.setProperty("--accent", t.accent);
      root.style.setProperty("--accent-soft", t.accent + "12");
    }
  }, [t.theme, t.accent]);

  const openContact = () => setContactOpen(true);

  return (
    <>
      <Header onContact={openContact} />
      <main>
        <Hero onContact={openContact} />        {/* 1 */}
        <Problemi />                            {/* 2 */}
        <ComeFunziona />                        {/* 3 */}
        <CosaOffro />                           {/* 4 */}
        <Risultati />                           {/* 5 */}
        <Casi />                                {/* 6 */}
        <Strumenti />                           {/* 7 */}
        <Processo />                            {/* 8 */}
        <FAQ />                                 {/* 9 */}
        <FinalCTA onContact={openContact} />    {/* 10 */}
      </main>
      <Footer />                                {/* 11 */}

      {t.showWhatsApp && <WhatsAppFloat />}
      <ContactDialog open={contactOpen} onClose={() => setContactOpen(false)} />

      <TweaksPanel title="Tweaks">
        <TweakSection label="Tema">
          <TweakRadio label="Sfondo" value={t.theme}
            onChange={(v) => setTweak("theme", v)}
            options={["chiaro", "scuro"]} />
          <TweakColor label="Accento" value={t.accent}
            onChange={(v) => setTweak("accent", v)}
            options={ACCENTS} />
        </TweakSection>
        <TweakSection label="Extra">
          <TweakToggle label="Pulsante WhatsApp" value={t.showWhatsApp}
            onChange={(v) => setTweak("showWhatsApp", v)} />
        </TweakSection>
      </TweaksPanel>
    </>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
