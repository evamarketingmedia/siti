/* global React, window */
const { useState, useEffect } = React;
const { Icon, Logo, Reveal, Brand, SectionHead } = window;

/* =========================================================
   HEADER
   ========================================================= */
const Header = ({ onContact }) => (
  <header className="site-header">
    <div className="container nav">
      <Brand />
      <nav className="nav-links" aria-label="primary">
        <a href="#problemi">Problemi</a>
        <a href="#come-funziona">Come funziona</a>
        <a href="#cosa-offro">Cosa offro</a>
        <a href="#casi">Casi reali</a>
        <a href="#processo">Processo</a>
      </nav>
      <div className="nav-cta">
        <button className="btn btn--primary" onClick={onContact}>
          Prenota una call <Icon name="arrow" size={14} className="arrow" />
        </button>
      </div>
    </div>
  </header>
);

/* =========================================================
   1. HERO
   ========================================================= */
const Hero = ({ onContact }) => (
  <section className="section hero" id="top">
    <div className="container hero-grid">
      <Reveal>
        <span className="hero-tag">
          <span className="dot" />
          Disponibile per 2 progetti · giugno
        </span>
        <h1 className="h-display">
          Il tuo sito dovrebbe <em>lavorare</em>.<br />Non solo esistere.
        </h1>
        <p className="lead">
          Trasformo siti web in sistemi automatici per acquisire clienti.
          Meno tempo perso a smistare richieste, più contatti che diventano
          appuntamenti — senza che tu debba toccare nulla.
        </p>
        <div className="hero-ctas">
          <button className="btn btn--primary btn--lg" onClick={onContact}>
            Prenota una call gratuita <Icon name="arrow" size={14} className="arrow" />
          </button>
          <a className="btn btn--lg" href="#come-funziona">Scopri come funziona</a>
        </div>
        <div className="hero-meta">
          <div className="hero-meta-item">
            <strong>2–3 sett.</strong>
            <span>Dal “sì” al sito online</span>
          </div>
          <div className="hero-meta-item">
            <strong>~5 min</strong>
            <span>Tempo medio di risposta al cliente</span>
          </div>
          <div className="hero-meta-item">
            <strong>1 referente</strong>
            <span>Sempre la stessa persona</span>
          </div>
        </div>
      </Reveal>

      <Reveal delay={120}>
        <HeroMock />
      </Reveal>
    </div>
  </section>
);

const HeroMock = () => (
  <div style={{ position: "relative" }}>
    <div className="mock">
      <div className="mock-chrome">
        <i /><i /><i />
        <span className="url">studio-quiet.it/sistemi/lead-flow</span>
      </div>
      <div className="mock-body">
        <div className="mock-head">
          <span>Workflow · ricezione lead</span>
          <span className="live">In esecuzione</span>
        </div>
        <div className="mock-step">
          <Logo kind="site" size={28} />
          <div>
            <span className="label">Anna ha lasciato i contatti</span>
            <span className="where">pagina “Cucina su misura” · da Google</span>
          </div>
          <span className="when">14:02</span>
        </div>
        <div className="mock-step">
          <Logo kind="sheets" size={28} />
          <div>
            <span className="label">Salvata sul foglio “Lead”</span>
            <span className="where">stato: nuovo · stima budget: medio</span>
          </div>
          <span className="when">14:02</span>
        </div>
        <div className="mock-step">
          <Logo kind="gmail" size={28} />
          <div>
            <span className="label">Risposta automatica inviata</span>
            <span className="where">conferma + 3 disponibilità per la call</span>
          </div>
          <span className="when">14:02</span>
        </div>
        <div className="mock-step">
          <Logo kind="whatsapp" size={28} />
          <div>
            <span className="label">Tu avvisato su WhatsApp</span>
            <span className="where">solo se richiesta calda · oggi sì</span>
          </div>
          <span className="when">14:03</span>
        </div>
      </div>
    </div>
    <div className="mock-tick">
      <strong>−6h</strong> di lavoro a settimana
    </div>
  </div>
);

/* =========================================================
   2. PROBLEMI REALI
   ========================================================= */
const Problemi = () => {
  const items = [
    {
      h: "Le richieste arrivano, ma non le vedi in tempo.",
      p: "Email aperta a fine giornata, modulo controllato il giorno dopo, qualcuno aveva già scelto qualcun altro.",
    },
    {
      h: "Messaggi sparsi su WhatsApp, email, telefono.",
      p: "Tre canali, tre quaderni mentali. Ogni tanto qualcuno cade nel mezzo e te ne accorgi solo settimane dopo.",
    },
    {
      h: "I preventivi richiedono troppo tempo.",
      p: "Mezz’ora di domande, mezz’ora di scrittura, il cliente intanto si è dimenticato perché ti aveva contattato.",
    },
    {
      h: "Clienti che non rispondono e non sai cosa fare.",
      p: "Aspettare? Risollecitare? Lasciar perdere? Senza un sistema diventa fortuna pura.",
    },
    {
      h: "Non hai un sistema. Solo fortuna e improvvisazione.",
      p: "I mesi buoni vanno alla grande. Quelli neutri sembrano un mistero. Non sai cosa funziona davvero.",
    },
  ];
  return (
    <section className="section" id="problemi">
      <div className="container">
        <SectionHead
          kicker="01 — Problemi reali"
          title="Le richieste dei clienti si perdono <em>ovunque</em>. Sistemiamolo."
          lead="Se ti riconosci in uno di questi, non ti serve un sito più bello. Ti serve un sito che lavori."
        />
        <div className="problems">
          {items.map((it, i) => (
            <Reveal key={i} className="problem" delay={i * 40}>
              <span className="pn">0{i + 1}</span>
              <h3>{it.h}</h3>
              <p>{it.p}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};

/* =========================================================
   3. COME FUNZIONA — horizontal workflow
   ========================================================= */
const ComeFunziona = () => {
  const steps = [
    {
      n: "01",
      icon: <Logo kind="site" size={32} />,
      h: "Cliente invia richiesta",
      p: "Dal sito, da WhatsApp o da un modulo dedicato. Quello che usa di più.",
    },
    {
      n: "02",
      icon: <Logo kind="sheets" size={32} />,
      h: "Sistema registra e organizza",
      p: "Tutto finisce nello stesso foglio: nome, fonte, priorità, data.",
    },
    {
      n: "03",
      icon: <Logo kind="gmail" size={32} />,
      h: "Risposta automatica + follow-up",
      p: "Conferma immediata al cliente. Promemoria a te se serve agire.",
    },
    {
      n: "04",
      icon: <Logo kind="notion" size={32} />,
      h: "Tu ricevi tutto in ordine",
      p: "Una sola vista. Cosa è caldo, cosa aspetta, cosa hai già chiuso.",
    },
    {
      n: "05",
      icon: <Logo kind="calendar" size={32} />,
      h: "Cliente diventa appuntamento",
      p: "Calendario sincronizzato, reminder 24h prima, niente no-show.",
    },
  ];
  return (
    <section className="section section--alt" id="come-funziona">
      <div className="container">
        <SectionHead
          kicker="02 — Come funziona"
          title="Un flusso semplice. <em>Cinque passi</em>, sempre uguali."
          lead="Non è magia. Sono strumenti collegati bene. Tu vedi solo il risultato: meno caos, più clienti già pronti a comprare."
        />
        <div className="wf-flow">
          {steps.map((s, i) => (
            <Reveal key={i} className="wf-card" delay={i * 80}>
              <span className="num">{s.n}</span>
              <div className="icon">{s.icon}</div>
              <h4>{s.h}</h4>
              <p>{s.p}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};

/* =========================================================
   4. COSA OFFRO — Siti + Automazioni
   ========================================================= */
const CosaOffro = () => (
  <section className="section" id="cosa-offro">
    <div className="container">
      <SectionHead
        kicker="03 — Cosa offro"
        title="Due cose. Una sola filosofia: <em>meno lavoro</em>, più clienti."
        lead="Puoi partire dal sito, dalle automazioni o da entrambi. Spesso si parte piccolo e si aggiunge col tempo."
      />
      <div className="offer">
        <Reveal className="offer-card">
          <span className="stag">Servizio 01</span>
          <h3>Siti web che <em>convertono</em>.</h3>
          <p className="desc">
            Niente brochure online. Pagine pensate per portare il visitatore a fare
            una cosa sola: contattarti.
          </p>
          <ul>
            {[
              "Design pulito e professionale",
              "Struttura pensata per ottenere richieste",
              "Mobile-first e veloci",
              "Testi che spiegano, non che riempiono",
              "Modulo + WhatsApp + chiamata rapida",
              "SEO base per farti trovare",
              "Consegna rapida, senza complicazioni",
            ].map((l) => (
              <li key={l}>
                <Icon name="check" size={14} strokeWidth={2.4} />
                {l}
              </li>
            ))}
          </ul>
          <div className="offer-preview">
            <div className="site-prev">
              <span className="lbl">Sito · esempio</span>
              <span className="nav-pills"><span /><span /><span /></span>
            </div>
            <div className="site-prev-body">
              <h5>Cucina su misura per la tua casa.</h5>
              <p>Sopralluogo gratuito in zona Verona · consegna in 6 settimane.</p>
              <span className="cta">Richiedi preventivo <Icon name="arrow" size={12} /></span>
            </div>
          </div>
        </Reveal>

        <Reveal className="offer-card" delay={100}>
          <span className="stag">Servizio 02</span>
          <h3>Automazioni che <em>fanno risparmiare tempo</em>.</h3>
          <p className="desc">
            Pochi strumenti, collegati bene. Ogni richiesta che arriva viene
            registrata, smistata e seguita — anche di notte e nei weekend.
          </p>
          <ul>
            {[
              "Risposte automatiche intelligenti",
              "Gestione lead + follow-up",
              "Promemoria e reminder",
              "Preventivi automatici in bozza",
              "Integrazione Gmail, WhatsApp, Calendar, Sheets, Notion",
              "Meno caos, più controllo",
            ].map((l) => (
              <li key={l}>
                <Icon name="check" size={14} strokeWidth={2.4} />
                {l}
              </li>
            ))}
          </ul>
          <div className="offer-preview">
            <div className="logo-grid" aria-label="Strumenti integrati">
              <div><Logo kind="whatsapp" size={32} /></div>
              <div><Logo kind="gmail" size={32} /></div>
              <div><Logo kind="sheets" size={32} /></div>
              <div><Logo kind="calendar" size={32} /></div>
              <div><Logo kind="notion" size={32} /></div>
            </div>
          </div>
        </Reveal>
      </div>
    </div>
  </section>
);

/* =========================================================
   5. RISULTATI E BENEFICI REALI
   ========================================================= */
const Risultati = () => {
  const items = [
    { big: "−80%", h: "Tempo perso in attività ripetitive", p: "Email standard, conferme, smistamento contatti: tutto in automatico." },
    { big: "+35%", h: "Richieste di contatto generate", p: "Sito che spiega bene + CTA chiari + form veloce = più persone che scrivono." },
    { big: "24/7", h: "Risposte automatiche ai clienti", p: "Il primo messaggio parte sempre. Anche la domenica alle 23." },
    { big: "100%", h: "Contatti organizzati e tracciati", p: "Niente lead persi tra Instagram, email e quaderni." },
  ];
  return (
    <section className="section" id="risultati">
      <div className="container">
        <SectionHead
          kicker="04 — Risultati reali"
          title="Numeri che si <em>vedono</em> nei conti."
          lead="Medie reali dai progetti dell’ultimo anno. Variano per settore — ma l’ordine di grandezza è onesto."
        />
        <div className="metrics">
          {items.map((it, i) => (
            <Reveal key={i} className="metric" delay={i * 60}>
              <span className="big">
                {it.big.includes("+") || it.big.includes("−")
                  ? <em>{it.big}</em>
                  : it.big}
              </span>
              <h4>{it.h}</h4>
              <p>{it.p}</p>
            </Reveal>
          ))}
        </div>
        <p className="metrics-disclaimer">
          Ogni attività è diversa. I numeri cambiano. Ma il sistema funziona.
        </p>
      </div>
    </section>
  );
};

/* =========================================================
   6. CASI REALI (zig-zag layout)
   ========================================================= */
const Casi = () => {
  const cases = [
    {
      kind: "Trattoria · 28 coperti",
      h: "Prenotazioni senza il telefono che squilla.",
      problem: "“Mi stanco a rispondere agli stessi messaggi. Perdo prenotazioni perché di sera sono in cucina.”",
      p: "Sito con menù, prenotazione via WhatsApp e risposte automatiche fuori orario. Tu lavori, il sistema risponde.",
      stat: { num: "−40%", label: "chiamate · +25% coperti weekend" },
      visual: <CaseVisualChat />,
    },
    {
      kind: "Studio commercialista",
      h: "Prima call solo con i clienti giusti.",
      problem: "“Il 70% delle persone che mi chiamava non era nemmeno il mio target. Tempo buttato.”",
      p: "Form di qualifica intelligente prima della call. Calendario integrato. Conferme e reminder automatici.",
      stat: { num: "Da 3h/sett.", label: "a 20 min · solo prospect qualificati" },
      visual: <CaseVisualForm />,
    },
    {
      kind: "Falegname · cucine su misura",
      h: "Preventivi che partono lo stesso giorno.",
      problem: "“Ricevevo richieste e impiegavo 3-4 giorni a rispondere. Metà clienti sceglieva altro nel frattempo.”",
      p: "Modulo guidato sul sito che raccoglie info utili. Bozza preventivo già scritta. Follow-up dopo 48h se silenzio.",
      stat: { num: "+22%", label: "lead convertiti in 60 giorni" },
      visual: <CaseVisualQuote />,
    },
    {
      kind: "Palestra · 180 iscritti",
      h: "Iscrizioni gestite senza segreteria.",
      problem: "“Avevo due persone a tempo pieno per gestire abbonamenti e prove. Una se n’è andata e non l’ho sostituita.”",
      p: "Prenotazione lezioni di prova online, reminder WhatsApp 24h prima, scadenze abbonamento in automatico.",
      stat: { num: "−30%", label: "no-show · −1 stipendio in segreteria" },
      visual: <CaseVisualSchedule />,
    },
  ];
  return (
    <section className="section section--alt" id="casi">
      <div className="container">
        <SectionHead
          kicker="05 — Casi reali"
          title="Quattro esempi <em>concreti</em>."
          lead="Settori diversi, problemi simili. Tutti hanno smesso di rincorrere e iniziato a ricevere."
        />
        <div className="cases">
          {cases.map((c, i) => (
            <Reveal key={i} className="case" delay={i * 50}>
              <div className="case-text">
                <span className="kind">{c.kind}</span>
                <h3>{c.h}</h3>
                <p className="problem-line">{c.problem}</p>
                <p>{c.p}</p>
                <div className="case-stat">
                  <span className="num">{c.stat.num}</span>
                  <span>{c.stat.label}</span>
                </div>
              </div>
              <div className="case-visual">
                {c.visual}
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};

/* Case visuals — realistic mini-mocks */
const CaseVisualChat = () => (
  <>
    <div className="vhead">
      <span><Logo kind="whatsapp" size={14} /> WhatsApp · Trattoria</span>
      <span>20:34</span>
    </div>
    <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 6, marginTop: 4 }}>
      <div style={cvBubble("in")}>Avete posto per 4 venerdì sera?</div>
      <div style={cvBubble("out")}>Sì, alle 20:00 o 21:30. Confermo io o cerchi un altro orario?</div>
      <div style={cvBubble("in")}>21:30 perfetto, grazie!</div>
      <div style={{ ...cvBubble("out"), background: "#0D0D0D", color: "white" }}>
        Prenotazione confermata · 4 persone, ven 21:30 ✓
      </div>
    </div>
    <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--muted)", letterSpacing: ".04em", textTransform: "uppercase" }}>
      Auto · 3 messaggi · 0 tocchi
    </span>
  </>
);

const CaseVisualForm = () => (
  <>
    <div className="vhead">
      <span>Form qualifica · pre-call</span>
      <span>passo 3 di 4</span>
    </div>
    <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 8, marginTop: 6 }}>
      <div style={cvField}>P. IVA o privato? <span style={cvPill}>P. IVA</span></div>
      <div style={cvField}>Fatturato annuo <span style={cvPill}>200k – 500k</span></div>
      <div style={cvField}>Cosa cerchi? <span style={cvPill}>Consulenza fiscale</span></div>
      <div style={{ ...cvField, background: "#0D0D0D", color: "white" }}>
        <span style={{ flex: 1 }}>Compatibilità</span>
        <span style={{ ...cvPill, background: "#2563EB", color: "white" }}>Alta</span>
      </div>
    </div>
  </>
);

const CaseVisualQuote = () => (
  <>
    <div className="vhead">
      <span><Logo kind="gmail" size={14} /> Bozza preventivo</span>
      <span>generato 2 min fa</span>
    </div>
    <div style={{ flex: 1, fontSize: 12, color: "var(--ink-2)", lineHeight: 1.5, marginTop: 6 }}>
      <p style={{ margin: 0 }}>Gent.le Sig.ra Conti,</p>
      <p style={{ margin: "8px 0" }}>
        come da richiesta del 14/03, le invio una <strong>stima indicativa</strong>{" "}
        per la cucina lineare 3.20m in rovere…
      </p>
      <div style={{ display: "flex", justifyContent: "space-between", padding: "6px 10px", background: "var(--paper)", borderRadius: 6, border: "1px solid var(--rule)", marginTop: 8 }}>
        <span>Totale stimato</span>
        <strong>€ 8.400 – 9.200</strong>
      </div>
    </div>
  </>
);

const CaseVisualSchedule = () => (
  <>
    <div className="vhead">
      <span><Logo kind="calendar" size={14} /> Settimana 12</span>
      <span>4 prove · 0 no-show</span>
    </div>
    <div style={{ flex: 1, display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 4, marginTop: 6 }}>
      {["L", "M", "M", "G", "V"].map((d, i) => (
        <div key={i} style={{ background: "var(--paper)", border: "1px solid var(--rule)", borderRadius: 4, padding: "6px 4px", display: "flex", flexDirection: "column", gap: 3, fontSize: 9 }}>
          <span style={{ color: "var(--muted)", fontFamily: "var(--font-mono)" }}>{d}</span>
          {i === 0 && <span style={cvSlot("#2563EB")}>9:00</span>}
          {i === 1 && <span style={cvSlot("#16A34A")}>11:30</span>}
          {i === 2 && <span style={cvSlot("#2563EB")}>18:00</span>}
          {i === 3 && <span style={cvSlot("#16A34A")}>9:00</span>}
          {i === 4 && <span style={cvSlot("#2563EB")}>19:00</span>}
        </div>
      ))}
    </div>
  </>
);

const cvBubble = (dir) => ({
  alignSelf: dir === "in" ? "flex-start" : "flex-end",
  background: dir === "in" ? "var(--paper)" : "#DCF8C6",
  border: dir === "in" ? "1px solid var(--rule)" : "1px solid #C8E6A6",
  padding: "7px 10px",
  borderRadius: 8,
  fontSize: 12,
  maxWidth: "85%",
  color: "var(--ink)",
});
const cvField = {
  display: "flex", justifyContent: "space-between", alignItems: "center",
  padding: "8px 10px",
  background: "var(--paper)",
  border: "1px solid var(--rule)",
  borderRadius: 6,
  fontSize: 12,
  color: "var(--ink-2)",
};
const cvPill = {
  fontFamily: "var(--font-mono)",
  fontSize: 10,
  padding: "2px 8px",
  background: "var(--surface)",
  border: "1px solid var(--rule)",
  borderRadius: 4,
  color: "var(--ink)",
};
const cvSlot = (color) => ({
  background: color, color: "white", padding: "2px 4px", borderRadius: 3, textAlign: "center",
});

/* =========================================================
   7. STRUMENTI E INTEGRAZIONI
   ========================================================= */
const Strumenti = () => (
  <section className="section" id="strumenti">
    <div className="container">
      <SectionHead
        kicker="06 — Strumenti"
        title="Lavoro con quello che <em>già usi</em>."
        lead="Niente piattaforme proprietarie da imparare. Gli strumenti li conosci già — io li metto in dialogo tra loro."
      />
      <div className="tools-strip">
        {[
          ["whatsapp", "WhatsApp"],
          ["gmail",    "Gmail"],
          ["sheets",   "Sheets"],
          ["calendar", "Calendar"],
          ["notion",   "Notion"],
          ["stripe",   "Stripe"],
          ["chatgpt",  "GPT"],
        ].map(([k, n]) => (
          <Reveal key={k} className="tool-cell" delay={0}>
            <Logo kind={k} size={40} />
            <span className="nm">{n}</span>
          </Reveal>
        ))}
      </div>
    </div>
  </section>
);

/* =========================================================
   8. PROCESSO
   ========================================================= */
const Processo = () => {
  const steps = [
    { n: "1", h: "Analisi della tua attività", p: "Mezz’ora di call. Capiamo cosa fai, dove perdi tempo, dove perdi clienti." },
    { n: "2", h: "Progettazione su misura", p: "Proposta in una pagina: sito, automazioni, tempi, prezzo. Niente PDF da 30 slide." },
    { n: "3", h: "Sviluppo e automazioni", p: "2–4 settimane. Ogni venerdì un aggiornamento. Vedi tutto su link privato." },
    { n: "4", h: "Lancio e ottimizzazione", p: "Si va online. Mezz’ora di formazione, video registrato. Un mese di supporto incluso." },
  ];
  return (
    <section className="section section--alt" id="processo">
      <div className="container">
        <SectionHead
          kicker="07 — Processo"
          title="Quattro passi. <em>Nessuna sorpresa</em>."
          lead="Sai sempre dove siamo, cosa stai pagando e quando arriva il prossimo aggiornamento."
        />
        <div className="steps">
          {steps.map((s, i) => (
            <Reveal key={i} className="step" delay={i * 80}>
              <div className="step-bubble">{s.n}</div>
              <h3>{s.h}</h3>
              <p>{s.p}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};

/* =========================================================
   9. FAQ
   ========================================================= */
const FAQ = () => {
  const faqs = [
    {
      q: "Quanto tempo serve per creare un sito?",
      a: "Per un sito vetrina due settimane, di cui 3–4 giorni in cui ci scambiamo testi e foto. Per un sito + automazioni siamo sulle 3–4 settimane. Se hai fretta vera te lo dico in call, senza promesse vuote.",
    },
    {
      q: "Posso aggiornare il sito in autonomia?",
      a: "Sì. Ti consegno il sito con un piccolo pannello e una mini guida video (15 min). Puoi cambiare testi, foto, orari, promo. Se preferisci delegare c’è anche un’opzione manutenzione.",
    },
    {
      q: "Le automazioni sono complicate?",
      a: "Dal tuo lato no — vedi solo il risultato (un’email che parte, un foglio che si aggiorna, un cliente che prenota). Io progetto e configuro tutto. Tu mi dici cosa deve succedere.",
    },
    {
      q: "Serve avere già testi e immagini?",
      a: "Non sempre. Se hai materiali ottimi, li sistemo. Se non li hai, scriviamo i testi insieme (te li mando in bozza, tu correggi) e usiamo foto curate o placeholder finché non avrai le tue.",
    },
    {
      q: "Posso iniziare solo dal sito?",
      a: "Assolutamente. È il percorso più comune: si parte dal sito, lo si fa funzionare, e si aggiungono automazioni quando emerge un collo di bottiglia concreto. Niente AI per il gusto di averla.",
    },
  ];
  return (
    <section className="section" id="faq">
      <div className="container">
        <SectionHead
          kicker="08 — Domande frequenti"
          title="Cose che mi chiedono <em>quasi sempre</em>."
          lead="Se non trovi la tua, scrivimi su WhatsApp: rispondo personalmente, di solito entro un’ora nei giorni feriali."
        />
        <div className="faq">
          {faqs.map((f, i) => (
            <Reveal as="details" key={i} className="faq-item" delay={i * 30}>
              <summary>
                {f.q}
                <span className="toggle" />
              </summary>
              <div className="answer">{f.a}</div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};

/* =========================================================
   10. FINAL CTA
   ========================================================= */
const FinalCTA = ({ onContact }) => (
  <section className="final" id="contatti">
    <div className="container">
      <Reveal>
        <div className="final-grid">
          <div>
            <span className="eyebrow" style={{ color: "#9CA3AF" }}>Pronto?</span>
            <h2 style={{ marginTop: 16 }}>
              Smetti di perdere richieste.<br /><em>Inizia a lavorare meglio.</em>
            </h2>
            <p>
              Prenota una call gratuita di 30 minuti. Quattro domande, due o tre cose
              concrete che puoi provare già la settimana prossima — anche senza lavorare con me.
            </p>
            <div className="hero-ctas">
              <button className="btn btn--primary btn--lg" onClick={onContact}>
                Prenota una call gratuita <Icon name="arrow" size={14} className="arrow" />
              </button>
              <a className="btn btn--ghost btn--lg" href="https://wa.me/" target="_blank" rel="noreferrer">
                Scrivimi su WhatsApp
              </a>
            </div>
          </div>
          <div className="final-side">
            <h5>Cosa succede dopo</h5>
            {[
              "Ti rispondo entro 24h, di persona — niente segreteria.",
              "Ti mando un link per scegliere giorno e orario.",
              "30 minuti, zero slide, zero impegno.",
              "Esci con almeno 2–3 idee concrete da applicare subito.",
            ].map((t, i) => (
              <div key={i} className="final-bullet">
                <Icon name="check" size={16} strokeWidth={2.4} />
                <span>{t}</span>
              </div>
            ))}
          </div>
        </div>
      </Reveal>
    </div>
  </section>
);

/* =========================================================
   11. FOOTER
   ========================================================= */
const Footer = () => (
  <footer className="site-footer">
    <div className="container">
      <div className="footer-top">
        <div className="footer-col">
          <Brand />
          <p className="footer-tag">
            “Creo siti che lavorano al posto tuo.”
          </p>
          <div className="footer-socials">
            <a href="#" aria-label="Instagram"><Icon name="instagram" size={16} /></a>
            <a href="#" aria-label="LinkedIn"><Icon name="linkedin" size={16} /></a>
          </div>
        </div>
        <div className="footer-col">
          <h5>Servizi</h5>
          <ul>
            <li><a href="#cosa-offro">Siti che convertono</a></li>
            <li><a href="#cosa-offro">Automazioni</a></li>
            <li><a href="#come-funziona">Come funziona</a></li>
            <li><a href="#casi">Casi reali</a></li>
          </ul>
        </div>
        <div className="footer-col">
          <h5>Link utili</h5>
          <ul>
            <li><a href="#problemi">Problemi</a></li>
            <li><a href="#processo">Processo</a></li>
            <li><a href="#faq">Domande frequenti</a></li>
            <li><a href="#contatti">Contatti</a></li>
          </ul>
        </div>
        <div className="footer-col">
          <h5>Contatti · legali</h5>
          <ul>
            <li><a href="mailto:ciao@studio-quiet.it">ciao@studio-quiet.it</a></li>
            <li><a href="https://wa.me/" target="_blank" rel="noreferrer">WhatsApp diretto</a></li>
            <li><a href="#">Privacy policy</a></li>
            <li><a href="#">Cookie policy</a></li>
          </ul>
        </div>
      </div>
      <div className="footer-bottom">
        <span>© {new Date().getFullYear()} Studio Quiet · P. IVA in registrazione</span>
        <span>Costruito a mano, sull’Appennino.</span>
      </div>
    </div>
  </footer>
);

/* =========================================================
   WHATSAPP FLOAT + CONTACT DIALOG
   ========================================================= */
const WhatsAppFloat = () => (
  <a className="wa-float" href="https://wa.me/" target="_blank" rel="noreferrer" aria-label="WhatsApp">
    <Logo kind="whatsapp" size={20} />
    <span className="txt">Scrivimi su WhatsApp</span>
  </a>
);

const ContactDialog = ({ open, onClose }) => {
  const [step, setStep] = useState(0);
  const [data, setData] = useState({ name: "", email: "", business: "", interest: "Sito che porta richieste", message: "" });

  useEffect(() => { if (!open) setStep(0); }, [open]);
  if (!open) return null;

  const submit = (e) => { e.preventDefault(); setStep(1); };

  return (
    <div className="dialog-overlay" role="dialog" aria-modal="true" onClick={onClose}>
      <div className="dialog" onClick={(e) => e.stopPropagation()}>
        <button className="close" onClick={onClose} aria-label="Chiudi">
          <Icon name="close" size={18} />
        </button>

        {step === 0 ? (
          <>
            <span className="eyebrow">Call · 30 min · gratis</span>
            <h3>Raccontami il caso.</h3>
            <p className="body" style={{ fontSize: 14, marginTop: 8 }}>
              Quattro campi, niente moduli infiniti. Ti rispondo entro 24h, di persona.
            </p>
            <form onSubmit={submit}>
              <div className="field"><label>Nome</label>
                <input required value={data.name} onChange={(e) => setData({ ...data, name: e.target.value })} /></div>
              <div className="field"><label>Email</label>
                <input type="email" required value={data.email} onChange={(e) => setData({ ...data, email: e.target.value })} /></div>
              <div className="field"><label>Cosa fai</label>
                <input placeholder="es. trattoria, studio commerciale, palestra…" value={data.business} onChange={(e) => setData({ ...data, business: e.target.value })} /></div>
              <div className="field">
                <label>Da dove partiamo</label>
                <div className="choice">
                  {["Sito che porta richieste", "Automazioni", "Tutti e due"].map((opt) => (
                    <button key={opt} type="button"
                      data-on={data.interest === opt ? "1" : "0"}
                      onClick={() => setData({ ...data, interest: opt })}>
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
              <div className="field"><label>Due righe sul problema (opzionale)</label>
                <textarea rows={3} value={data.message} onChange={(e) => setData({ ...data, message: e.target.value })} /></div>
              <button className="btn btn--primary" type="submit" style={{ justifyContent: "center", marginTop: 6 }}>
                Invia <Icon name="arrow" size={14} className="arrow" />
              </button>
              <p className="muted" style={{ fontSize: 11, textAlign: "center", margin: 0 }}>
                Non userò mai i tuoi dati per altro. Promesso.
              </p>
            </form>
          </>
        ) : (
          <div style={{ textAlign: "center", padding: "16px 0" }}>
            <div style={{
              width: 48, height: 48, borderRadius: "50%", margin: "0 auto 18px",
              background: "var(--accent)", color: "white", display: "grid", placeItems: "center",
            }}>
              <Icon name="check" size={22} strokeWidth={2.4} />
            </div>
            <h3 style={{ fontSize: 26, margin: "0 0 8px" }}>Ricevuto.</h3>
            <p className="body" style={{ fontSize: 14, maxWidth: "36ch", margin: "0 auto 24px" }}>
              Ti rispondo entro 24h via email. Se hai fretta vera, WhatsApp è più veloce.
            </p>
            <div style={{ display: "flex", gap: 10, justifyContent: "center" }}>
              <a className="btn" href="https://wa.me/" target="_blank" rel="noreferrer">WhatsApp</a>
              <button className="btn btn--primary" onClick={onClose}>Chiudi</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

Object.assign(window, {
  Header, Hero,
  Problemi, ComeFunziona, CosaOffro, Risultati, Casi,
  Strumenti, Processo, FAQ, FinalCTA, Footer,
  WhatsAppFloat, ContactDialog,
});
